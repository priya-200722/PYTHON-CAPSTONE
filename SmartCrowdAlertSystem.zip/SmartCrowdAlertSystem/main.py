# ==========================================================
# AI SMART CROWD ALERT SYSTEM
# PART 2 - AREA + YOLO + DENSITY PROTOTYPE
# ==========================================================

import cv2
import numpy as np

from detector import detect_people

from config import (
    VIDEO_PATH,
    MONITORING_AREA,
    SAFE_CAPACITY_DENSITY,
    LOW_DENSITY,
    MEDIUM_DENSITY,
    HIGH_DENSITY,
    EMERGENCY_DENSITY,
    WINDOW_NAME
)


# ==========================================================
# GLOBAL VARIABLES FOR AREA SELECTION
# ==========================================================

roi_points = []

drawing_finished = False


# ==========================================================
# MOUSE CALLBACK
# ==========================================================

def mouse_callback(event, x, y, flags, param):

    global roi_points
    global drawing_finished

    # Left click = add point
    if event == cv2.EVENT_LBUTTONDOWN:

        if not drawing_finished:

            roi_points.append(
                (x, y)
            )


# ==========================================================
# DRAW ROI
# ==========================================================

def draw_roi(frame):

    global roi_points

    output = frame.copy()

    # Draw selected points
    for point in roi_points:

        cv2.circle(
            output,
            point,
            6,
            (0, 255, 255),
            -1
        )

    # Draw connecting lines
    if len(roi_points) > 1:

        for i in range(
            len(roi_points) - 1
        ):

            cv2.line(
                output,
                roi_points[i],
                roi_points[i + 1],
                (0, 255, 255),
                2
            )

    # Close polygon
    if len(roi_points) >= 3:

        cv2.line(
            output,
            roi_points[-1],
            roi_points[0],
            (0, 255, 255),
            2
        )

    # Instructions
    cv2.putText(
        output,
        "Click points around monitoring area",
        (20, 35),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.8,
        (0, 255, 255),
        2
    )

    cv2.putText(
        output,
        "Press ENTER when finished",
        (20, 70),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (255, 255, 255),
        2
    )

    cv2.putText(
        output,
        "Press R to reset",
        (20, 105),
        cv2.FONT_HERSHEY_SIMPLEX,
        0.7,
        (255, 255, 255),
        2
    )

    return output


# ==========================================================
# CALCULATE PIXEL AREA
# ==========================================================

def calculate_pixel_area():

    if len(roi_points) < 3:
        return 0

    polygon = np.array(
        roi_points,
        dtype=np.int32
    )

    area = cv2.contourArea(
        polygon
    )

    return area


# ==========================================================
# CALCULATE RISK
# ==========================================================

def calculate_risk(density, occupancy):

    if density >= EMERGENCY_DENSITY:

        return "EMERGENCY"

    elif density >= HIGH_DENSITY:

        return "HIGH"

    elif density >= MEDIUM_DENSITY:

        return "MEDIUM"

    elif density >= LOW_DENSITY:

        return "LOW"

    else:

        return "SAFE"


# ==========================================================
# RISK DISPLAY COLOR
# ==========================================================

def risk_color(risk):

    if risk == "SAFE":
        return (0, 255, 0)

    elif risk == "LOW":
        return (0, 255, 0)

    elif risk == "MEDIUM":
        return (0, 255, 255)

    elif risk == "HIGH":
        return (0, 165, 255)

    else:
        return (0, 0, 255)


# ==========================================================
# MAIN
# ==========================================================

def main():

    global roi_points
    global drawing_finished

    # ------------------------------------------------------
    # OPEN VIDEO
    # ------------------------------------------------------

    cap = cv2.VideoCapture(
        VIDEO_PATH
    )

    if not cap.isOpened():

        print()
        print("ERROR: Could not open video.")
        print(
            "Check that the video exists at:"
        )
        print(VIDEO_PATH)

        return

    # ------------------------------------------------------
    # READ FIRST FRAME
    # ------------------------------------------------------

    ret, first_frame = cap.read()

    if not ret:

        print(
            "ERROR: Could not read video."
        )

        cap.release()

        return

    # ------------------------------------------------------
    # CREATE WINDOW
    # ------------------------------------------------------

    cv2.namedWindow(
        WINDOW_NAME,
        cv2.WINDOW_NORMAL
    )

    cv2.setMouseCallback(
        WINDOW_NAME,
        mouse_callback
    )

    # ------------------------------------------------------
    # AREA SELECTION
    # ------------------------------------------------------

    print()
    print("=" * 60)
    print("MONITORING AREA SELECTION")
    print("=" * 60)
    print()
    print("Click points around the area")
    print("that you want to monitor.")
    print()
    print("Press ENTER when finished.")
    print("Press R to reset.")
    print("Press ESC to exit.")
    print()

    while True:

        display = draw_roi(
            first_frame
        )

        cv2.imshow(
            WINDOW_NAME,
            display
        )

        key = cv2.waitKey(20) & 0xFF

        # ENTER
        if key == 13:

            if len(roi_points) >= 3:

                drawing_finished = True

                break

            else:

                print(
                    "Please select at least 3 points."
                )

        # R = reset
        elif key == ord("r"):

            roi_points.clear()

        # ESC
        elif key == 27:

            cap.release()

            cv2.destroyAllWindows()

            return

    # ------------------------------------------------------
    # CALCULATE PIXEL AREA
    # ------------------------------------------------------

    pixel_area = calculate_pixel_area()

    print()
    print("=" * 60)
    print("AREA INFORMATION")
    print("=" * 60)

    print(
        f"Selected ROI pixel area : {pixel_area:.2f} pixels²"
    )

    print(
        f"Configured real area     : {MONITORING_AREA:.2f} m²"
    )

    # ------------------------------------------------------
    # REAL WORLD AREA
    # ------------------------------------------------------

    print()
    print(
        "IMPORTANT: The program cannot determine real"
    )
    print(
        "square metres from pixels without calibration."
    )

    print()
    print(
        f"Using configured area: {MONITORING_AREA:.2f} m²"
    )

    real_area = MONITORING_AREA

    # ------------------------------------------------------
    # MAXIMUM CAPACITY
    # ------------------------------------------------------

    maximum_capacity = int(
        real_area *
        SAFE_CAPACITY_DENSITY
    )

    print(
        f"Maximum configured capacity: "
        f"{maximum_capacity} people"
    )

    print()
    print("=" * 60)
    print("STARTING AI CROWD ANALYSIS")
    print("=" * 60)
    print()

    # ------------------------------------------------------
    # START VIDEO FROM BEGINNING
    # ------------------------------------------------------

    cap.set(
        cv2.CAP_PROP_POS_FRAMES,
        0
    )

    # ------------------------------------------------------
    # MAIN VIDEO LOOP
    # ------------------------------------------------------

    while True:

        ret, frame = cap.read()

        if not ret:
            break

        # --------------------------------------------------
        # YOLO DETECTION
        # --------------------------------------------------

        output_frame, people_count, detected_people = (
            detect_people(
                frame,
                roi_points
            )
        )

        # --------------------------------------------------
        # DRAW MONITORING REGION
        # --------------------------------------------------

        polygon = np.array(
            roi_points,
            dtype=np.int32
        )

        # --------------------------------------------------
        # CALCULATE DENSITY
        # --------------------------------------------------

        density = (
            people_count /
            real_area
        )

        # --------------------------------------------------
        # OCCUPANCY
        # --------------------------------------------------

        if maximum_capacity > 0:

            occupancy = (
                people_count /
                maximum_capacity
            ) * 100

        else:

            occupancy = 0

        # Limit display to 100+
        occupancy_display = min(
            occupancy,
            100
        )

        # --------------------------------------------------
        # RISK
        # --------------------------------------------------

        risk = calculate_risk(
            density,
            occupancy
        )

        # --------------------------------------------------
        # ALERT
        # --------------------------------------------------

        if risk in [
            "HIGH",
            "EMERGENCY"
        ]:

            alert_status = "ON"

        else:

            alert_status = "OFF"

        # --------------------------------------------------
        # ROI COLOR
        # --------------------------------------------------

        color = risk_color(
            risk
        )

        cv2.polylines(
            output_frame,
            [polygon],
            True,
            color,
            4
        )

        # --------------------------------------------------
        # DARK DASHBOARD PANEL
        # --------------------------------------------------

        overlay = output_frame.copy()

        cv2.rectangle(
            overlay,
            (10, 120),
            (470, 430),
            (0, 0, 0),
            -1
        )

        output_frame = cv2.addWeighted(
            overlay,
            0.65,
            output_frame,
            0.35,
            0
        )

        # --------------------------------------------------
        # TITLE
        # --------------------------------------------------

        cv2.putText(
            output_frame,
            "AI SMART CROWD ALERT SYSTEM",
            (20, 155),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )

        # --------------------------------------------------
        # PEOPLE COUNT
        # --------------------------------------------------

        cv2.putText(
            output_frame,
            f"People Count : {people_count}",
            (20, 195),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.75,
            (255, 255, 255),
            2
        )

        # --------------------------------------------------
        # AREA
        # --------------------------------------------------

        cv2.putText(
            output_frame,
            f"Monitoring Area : {real_area:.1f} m2",
            (20, 235),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )

        # --------------------------------------------------
        # DENSITY
        # --------------------------------------------------

        cv2.putText(
            output_frame,
            f"Density : {density:.2f} persons/m2",
            (20, 275),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )

        # --------------------------------------------------
        # CAPACITY
        # --------------------------------------------------

        cv2.putText(
            output_frame,
            f"Maximum Capacity : {maximum_capacity}",
            (20, 315),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )

        # --------------------------------------------------
        # OCCUPANCY
        # --------------------------------------------------

        cv2.putText(
            output_frame,
            f"Occupancy : {occupancy_display:.1f}%",
            (20, 355),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            (255, 255, 255),
            2
        )

        # --------------------------------------------------
        # RISK
        # --------------------------------------------------

        cv2.putText(
            output_frame,
            f"Risk : {risk}",
            (20, 395),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.75,
            color,
            3
        )

        # --------------------------------------------------
        # ALERT
        # --------------------------------------------------

        cv2.putText(
            output_frame,
            f"Alert Status : {alert_status}",
            (20, 425),
            cv2.FONT_HERSHEY_SIMPLEX,
            0.7,
            color,
            2
        )

        # --------------------------------------------------
        # SHOW VIDEO
        # --------------------------------------------------

        cv2.imshow(
            WINDOW_NAME,
            output_frame
        )

        # --------------------------------------------------
        # KEYBOARD
        # --------------------------------------------------

        key = cv2.waitKey(1) & 0xFF

        # Q = quit
        if key == ord("q"):

            break

    # ------------------------------------------------------
    # RELEASE
    # ------------------------------------------------------

    cap.release()

    cv2.destroyAllWindows()

    print()
    print("=" * 60)
    print("CROWD ANALYSIS FINISHED")
    print("=" * 60)


# ==========================================================
# RUN
# ==========================================================

if __name__ == "__main__":

    main()