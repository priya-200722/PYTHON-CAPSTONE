# ==========================================================
# YOLO PERSON DETECTION MODULE
# AI SMART CROWD ALERT SYSTEM
# ==========================================================

from ultralytics import YOLO
import cv2
import numpy as np

from config import (
    YOLO_MODEL,
    CONFIDENCE,
    IMAGE_SIZE
)


# ==========================================================
# LOAD YOLO MODEL
# ==========================================================

print("Loading YOLO model...")

model = YOLO(YOLO_MODEL)

print("YOLO model loaded successfully.")


# ==========================================================
# CHECK WHETHER A POINT IS INSIDE THE MONITORING AREA
# ==========================================================

def point_inside_roi(point, roi_points):

    # If a valid polygon is not selected
    if roi_points is None or len(roi_points) < 3:
        return False

    # Convert ROI points to NumPy polygon
    polygon = np.array(
        roi_points,
        dtype=np.int32
    )

    # Check whether point is inside polygon
    result = cv2.pointPolygonTest(
        polygon,
        point,
        False
    )

    return result >= 0


# ==========================================================
# DETECT PEOPLE INSIDE MONITORING AREA
# ==========================================================

def detect_people(frame, roi_points):

    # ------------------------------------------------------
    # YOLO TRACKING
    # ------------------------------------------------------

    results = model.track(
        frame,

        # Keep tracking IDs between frames
        persist=True,

        # COCO class 0 = person
        classes=[0],

        # Detection confidence
        conf=CONFIDENCE,

        # Image size
        imgsz=IMAGE_SIZE,

        # ByteTrack tracker
        tracker="bytetrack.yaml",

        # Don't print YOLO information for every frame
        verbose=False
    )

    # ------------------------------------------------------
    # COPY FRAME
    # ------------------------------------------------------

    output_frame = frame.copy()

    # ------------------------------------------------------
    # PEOPLE COUNT
    # ------------------------------------------------------

    people_count = 0

    # Store detected people
    detected_people = []

    # ------------------------------------------------------
    # PROCESS YOLO RESULTS
    # ------------------------------------------------------

    for result in results:

        # If no bounding boxes were detected
        if result.boxes is None:
            continue

        boxes = result.boxes

        # --------------------------------------------------
        # PROCESS EACH DETECTION
        # --------------------------------------------------

        for i in range(len(boxes)):

            # ------------------------------------------------
            # BOUNDING BOX
            # ------------------------------------------------

            x1, y1, x2, y2 = map(
                int,
                boxes.xyxy[i].tolist()
            )

            # ------------------------------------------------
            # CONFIDENCE
            # ------------------------------------------------

            confidence = float(
                boxes.conf[i]
            )

            # ------------------------------------------------
            # CLASS ID
            # ------------------------------------------------

            class_id = int(
                boxes.cls[i]
            )

            # ------------------------------------------------
            # ONLY PERSON CLASS
            # ------------------------------------------------

            if class_id != 0:
                continue

            # =================================================
            # IMPORTANT CHANGE
            # =================================================
            #
            # Instead of using the center of the bounding box,
            # we use the BOTTOM-CENTER.
            #
            # This approximately represents where the person's
            # feet touch the floor.
            #
            # This is more appropriate for a floor-based
            # crowd monitoring region.
            # =================================================

            bottom_center_x = int(
                (x1 + x2) / 2
            )

            bottom_center_y = int(
                y2
            )

            floor_point = (
                bottom_center_x,
                bottom_center_y
            )

            # ------------------------------------------------
            # CHECK WHETHER PERSON IS INSIDE ROI
            # ------------------------------------------------

            inside = point_inside_roi(
                floor_point,
                roi_points
            )

            # =================================================
            # PERSON INSIDE MONITORING AREA
            # =================================================

            if inside:

                # Increase people count
                people_count += 1

                # Store detection information
                detected_people.append(
                    {
                        "box": (
                            x1,
                            y1,
                            x2,
                            y2
                        ),

                        "center": floor_point,

                        "confidence": confidence
                    }
                )

                # ------------------------------------------------
                # GREEN BOX
                # ------------------------------------------------

                cv2.rectangle(
                    output_frame,

                    (x1, y1),

                    (x2, y2),

                    (0, 255, 0),

                    2
                )

                # ------------------------------------------------
                # FLOOR POINT
                # ------------------------------------------------

                cv2.circle(
                    output_frame,

                    floor_point,

                    5,

                    (0, 255, 255),

                    -1
                )

                # ------------------------------------------------
                # LABEL
                # ------------------------------------------------

                cv2.putText(
                    output_frame,

                    f"Person {confidence:.2f}",

                    (
                        x1,
                        max(y1 - 8, 20)
                    ),

                    cv2.FONT_HERSHEY_SIMPLEX,

                    0.5,

                    (0, 255, 0),

                    2
                )

            # =================================================
            # PERSON OUTSIDE MONITORING AREA
            # =================================================

            else:

                # Grey box for people outside ROI
                cv2.rectangle(
                    output_frame,

                    (x1, y1),

                    (x2, y2),

                    (150, 150, 150),

                    1
                )

                # Optional small grey floor point
                cv2.circle(
                    output_frame,

                    floor_point,

                    3,

                    (150, 150, 150),

                    -1
                )

    # ======================================================
    # RETURN RESULTS
    # ======================================================

    return (
        output_frame,
        people_count,
        detected_people
    )