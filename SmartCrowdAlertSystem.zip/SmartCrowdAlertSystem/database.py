import sqlite3
from config import DATABASE_NAME

def create_database():

    conn = sqlite3.connect(DATABASE_NAME)

    cursor = conn.cursor()

    cursor.execute("""

    CREATE TABLE IF NOT EXISTS crowd_logs(

        id INTEGER PRIMARY KEY AUTOINCREMENT,

        date TEXT,

        time TEXT,

        people_count INTEGER,

        monitoring_area REAL,

        density REAL,

        maximum_capacity INTEGER,

        occupancy REAL,

        risk TEXT,

        alert TEXT

    )

    """)

    conn.commit()

    conn.close()

def insert_log(date,time,count,area,density,capacity,occupancy,risk,alert):

    conn=sqlite3.connect(DATABASE_NAME)

    cursor=conn.cursor()

    cursor.execute("""

    INSERT INTO crowd_logs

    (date,time,people_count,monitoring_area,density,maximum_capacity,occupancy,risk,alert)

    VALUES(?,?,?,?,?,?,?,?,?)

    """,(date,time,count,area,density,capacity,occupancy,risk,alert))

    conn.commit()

    conn.close()