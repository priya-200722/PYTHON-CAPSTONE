# ==========================================================
# AI SMART CROWD ALERT SYSTEM - CONFIGURATION
# ==========================================================

# ----------------------------------------------------------
# VIDEO
# ----------------------------------------------------------

VIDEO_PATH = "videos/crowd.mp4"


# ----------------------------------------------------------
# YOLO MODEL
# ----------------------------------------------------------

# YOLOv8 Medium is more accurate than YOLOv8 Nano
# especially for crowded scenes.

YOLO_MODEL = "yolov8m.pt"

# Detection confidence
CONFIDENCE = 0.25

# Image size used by YOLO
# Higher size can improve small-person detection,
# but requires more processing power.

IMAGE_SIZE = 1280


# ----------------------------------------------------------
# REAL-WORLD MONITORING AREA
# ----------------------------------------------------------

# IMPORTANT:
# This must be the actual physical area represented
# by the selected monitoring region.

MONITORING_AREA = 20.0


# ----------------------------------------------------------
# CROWD DENSITY THRESHOLDS
# ----------------------------------------------------------

# These are PROJECT CONFIGURATION VALUES.
# They can be changed after testing and validation.

LOW_DENSITY = 1.0

MEDIUM_DENSITY = 2.0

HIGH_DENSITY = 3.0

EMERGENCY_DENSITY = 4.0


# ----------------------------------------------------------
# CAPACITY
# ----------------------------------------------------------

# Maximum configured capacity based on the selected
# safe-density value.

SAFE_CAPACITY_DENSITY = 3.0

MAX_CAPACITY = int(
    MONITORING_AREA * SAFE_CAPACITY_DENSITY
)


# ----------------------------------------------------------
# WINDOW
# ----------------------------------------------------------

WINDOW_NAME = "AI Smart Crowd Alert System"


# ----------------------------------------------------------
# ALERT
# ----------------------------------------------------------

ALERT_SOUND = "assets/alarm.wav"